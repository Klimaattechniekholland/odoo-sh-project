import requests
from odoo import models
from odoo.exceptions import UserError

class AIService(models.AbstractModel):
    _name = 'ai_integration.service'
    _description = 'AI Service'

    def _get_api_key(self):
        return self.env['ir.config_parameter'].sudo().get_param('ai_integration.api_key') or ''

    def ask_ai(self, prompt):
        api_key = self._get_api_key()
        if not api_key:
            raise UserError("API-key is niet ingesteld in AI-configuratie.")
        response = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {api_key}"},
            json={
                "model": "gpt-4o-mini",
                "messages": [{"role": "user", "content": prompt}]
            }
        )
        data = response.json()
        return data['choices'][0]['message']['content']
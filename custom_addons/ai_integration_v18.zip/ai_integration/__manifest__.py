{
    'name': 'AI Integration',
    'version': '18.0.1.0.0',
    'category': 'Tools',
    'summary': 'Integrates AI services into Odoo',
    'description': """Module to connect Odoo v18 (Odoo.sh compatible) with external LLM providers for AI-driven features.""",
    'author': 'Your Company',
    'website': 'https://yourcompany.com',
    'license': 'LGPL-3',
    'depends': ['base', 'mail'],
    'data': [
        'views/ai_config_views.xml',
        'views/ai_widget_templates.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'ai_integration/static/src/js/ai_widget.js',
        ],
        'web.assets_qweb': [
            'ai_integration/static/src/xml/ai_widget_templates.xml',
        ],
    },
    'installable': True,
    'application': False,
    'auto_install': False,
}
